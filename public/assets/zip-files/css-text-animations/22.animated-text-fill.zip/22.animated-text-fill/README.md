# Animated text fill

A Pen created on CodePen.io. Original URL: [https://codepen.io/zitrusfrisch/pen/DbwjOR](https://codepen.io/zitrusfrisch/pen/DbwjOR).

Fill your text with animated background images - no Javascript required, Webkit only.