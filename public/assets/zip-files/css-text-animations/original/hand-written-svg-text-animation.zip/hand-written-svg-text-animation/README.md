# Hand written SVG text animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/mellis84/pen/JpVZNw](https://codepen.io/mellis84/pen/JpVZNw).

A little hand written text animation made with anime.js. The masking is a little rough but you get the idea :P.