# Text Animations 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Mansoour/pen/bxBOPE](https://codepen.io/Mansoour/pen/bxBOPE).

simple texts  animation with a background & typewriter effect