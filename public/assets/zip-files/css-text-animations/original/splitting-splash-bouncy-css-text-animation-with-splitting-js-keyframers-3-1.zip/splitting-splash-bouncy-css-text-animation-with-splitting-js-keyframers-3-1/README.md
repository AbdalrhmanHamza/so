# Splitting Splash 🌊 | Bouncy CSS Text Animation with Splitting.js | @keyframers 3.1

A Pen created on CodePen.io. Original URL: [https://codepen.io/team/keyframers/pen/vYNyWwQ](https://codepen.io/team/keyframers/pen/vYNyWwQ).

David Khourshid & Stephen Shaw make a splash recreating a fantastic animation. Learn more about animating text, CSS variables and coordinating multiple elements!

* 💡 Inspiration: https://dribbble.com/shots/11113924-Laundry-Splash
* 📺 Video: https://youtu.be/hVqCPXzD_hA
* 💻 Code: https://codepen.io/team/keyframers/pen/vYNyWwQ


Additional Resources:

* Splitting.js https://splitting.js.org/
* CSS minmax https://developer.mozilla.org/en-US/docs/Web/CSS/min
* Alex the CSS Husky https://codepen.io/davidkpiano/pen/wMqXea
* David's article about animating Alex the CSS Husky: https://tympanus.net/codrops/2016/03/21/animated-animals-css-svg/
* SVGOMG SVG Optimizer https://jakearchibald.github.io/svgomg/


Like what we're doing? Support @keyframers so we can keep providing awesome content!

* Like & subscribe on YouTube at https://youtube.com/keyframers
* Buy web dev shirts, stickers & more at https://keyframe.rs/merch
* Follow & tweet us at https://twitter.com/keyframers
* Support us on Patreon at https://patreon.com/keyframers 

Topics covered:

* CSS Animation
* Coordinating multiple animations
* CSS Variables
* SVG Animation