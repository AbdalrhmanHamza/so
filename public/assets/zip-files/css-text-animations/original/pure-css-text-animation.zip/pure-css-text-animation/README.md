# Pure CSS Text Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/RobinTreur/pen/QKjgPX](https://codepen.io/RobinTreur/pen/QKjgPX).

