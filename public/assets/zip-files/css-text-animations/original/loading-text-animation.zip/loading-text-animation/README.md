# Loading Text Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/brunjo/pen/ByjRPy](https://codepen.io/brunjo/pen/ByjRPy).

