# Text Animation?

A Pen created on CodePen.io. Original URL: [https://codepen.io/short/pen/VyNqPa](https://codepen.io/short/pen/VyNqPa).

