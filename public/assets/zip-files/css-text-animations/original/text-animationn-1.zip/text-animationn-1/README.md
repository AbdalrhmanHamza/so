# Text Animation - N° 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/carloscdev/pen/mdBLmwP](https://codepen.io/carloscdev/pen/mdBLmwP).

