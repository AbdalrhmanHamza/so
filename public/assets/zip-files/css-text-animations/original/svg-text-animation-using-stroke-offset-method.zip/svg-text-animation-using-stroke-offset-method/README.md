# SVG Text Animation Using Stroke Offset Method

A Pen created on CodePen.io. Original URL: [https://codepen.io/Ayachem/pen/KaLbZK](https://codepen.io/Ayachem/pen/KaLbZK).

Loved the text animation at Wokine.com so I tried to recreate it here.  I noticed they used simple shapes to create the words.  I did that using svg lines and circles, and animated the stroke-offset attribute of each one to give it this animation.  Animated it using css keyframes and animations. 