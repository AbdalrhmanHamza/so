# Title Text Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/RobinTreur/pen/pyWLeB](https://codepen.io/RobinTreur/pen/pyWLeB).

Title Text Animation with GSAP, TimelineMax