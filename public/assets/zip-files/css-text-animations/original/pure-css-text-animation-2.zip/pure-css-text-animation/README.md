# Pure CSS Text Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/arlinacode/pen/BxgRPb](https://codepen.io/arlinacode/pen/BxgRPb).

Pure CSS Text Animation