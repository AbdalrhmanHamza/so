# THREE Text Animation #5

A Pen created on CodePen.io. Original URL: [https://codepen.io/zadvorsky/pen/BKJQep](https://codepen.io/zadvorsky/pen/BKJQep).

Fifth in a series of experiments with THREE.js and type.