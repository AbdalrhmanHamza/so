# SVG - CSS Text Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/MIMAXUZ/pen/LvpwZR](https://codepen.io/MIMAXUZ/pen/LvpwZR).

