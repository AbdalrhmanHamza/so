# Decode Text Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/BRacicot/pen/Nryjpa](https://codepen.io/BRacicot/pen/Nryjpa).

Text that appears to "decode" as if the characters where encrypted.

4 states per letter:
Transparent/Line/Block/Visible.
These states are shuffled for a unique "decode" effect each time.