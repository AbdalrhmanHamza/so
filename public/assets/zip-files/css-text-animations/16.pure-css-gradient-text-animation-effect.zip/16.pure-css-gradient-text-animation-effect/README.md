# Pure CSS Gradient Text Animation Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/caseycallow/pen/yMNqPY](https://codepen.io/caseycallow/pen/yMNqPY).

