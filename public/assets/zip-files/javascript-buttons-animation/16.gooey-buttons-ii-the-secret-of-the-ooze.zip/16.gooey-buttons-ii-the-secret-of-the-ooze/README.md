# Gooey Buttons II: The Secret of the Ooze

A Pen created on CodePen.io. Original URL: [https://codepen.io/cobra_winfrey/pen/mdGBGEO](https://codepen.io/cobra_winfrey/pen/mdGBGEO).

