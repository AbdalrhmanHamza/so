# 3D Pause Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/bGwmYKQ](https://codepen.io/havardob/pen/bGwmYKQ).

Utilizing box-shadow and gradients to recreate Lina Artista's 3D Toggle from this Dribbble shot: https://dribbble.com/shots/9067382-Toggle-Button-Design

Edit 01.13.2021: added the role-attribute to the button and some Javascript to make the button work as well