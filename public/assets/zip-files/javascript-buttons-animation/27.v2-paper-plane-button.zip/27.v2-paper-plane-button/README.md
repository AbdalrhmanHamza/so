# (v2) Paper plane button

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/BajabVN](https://codepen.io/aaroniker/pen/BajabVN).

