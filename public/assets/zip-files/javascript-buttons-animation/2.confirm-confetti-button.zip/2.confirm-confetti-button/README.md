# Confirm confetti button

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/bGVGNrV](https://codepen.io/aaroniker/pen/bGVGNrV).

