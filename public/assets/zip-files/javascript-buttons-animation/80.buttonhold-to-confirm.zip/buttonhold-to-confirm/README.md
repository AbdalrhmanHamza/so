# Button - Hold to confirm

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/WNNWQbM](https://codepen.io/aaroniker/pen/WNNWQbM).

