const { to, set, from, fromTo } = gsap

document.querySelectorAll('.dl-button').forEach(button => {
    button.addEventListener('pointerdown', e => {
        if(button.classList.contains('animating')) {
            return
        }
        to(button, {
            '--scale': .975,
            duration: .15
        })
    })
    button.addEventListener('pointerup', e => {
        if(button.classList.contains('animating')) {
            return
        }
        to(button, {
            '--scale': 1,
            duration: .15
        })
    })
    button.addEventListener('pointerleave', e => {
        if(button.classList.contains('animating')) {
            return
        }
        to(button, {
            '--scale': 1,
            duration: .15
        })
    })
    button.addEventListener('click', e => {

        e.preventDefault()

        button.classList.add('animating')

        if(button.classList.contains('done')) {
            to(button, {
                '--success-o': 0,
                duration: .15
            })
            to(button, {
                '--default-o': 1,
                duration: .4,
                clearProps: true,
                onComplete() {
                    button.classList.remove('animating', 'done')
                }
            })
            return
        }

        to(button, {
            '--rotate': '-90deg',
            '--y': '25px',
            '--default-o': 0,
            duration: .2
        })

        to(button, {
            keyframes: [{
                '--truck-base-x': '-4px',
                duration: .5
            }, {
                '--truck-base-x': '0px',
                duration: .2
            }, {
                '--truck-base-x': '60px',
                '--box-x': '-60px',
                duration: .5,
                onStart() {
                    setTimeout(() => {
                        to(button, {
                            keyframes: [{
                                '--box-y': '10px',
                                '--box-r': '-8deg',
                                duration: .2
                            }, {
                                '--box-r': '0deg',
                                duration: .2
                            }]
                        })
                    }, 200)
                }
            }, {
                '--truck-base-x': '56px',
                '--box-x': '-56px',
                duration: .4
            }, {
                '--light-opacity': 0,
                duration: .3,
                delay: .2
            }],
            onComplete() {
                setTimeout(() => {
                    button.classList.add('done')
                    button.classList.remove('animating')
                    to(button, {
                        keyframes: [{
                            '--rotate': '0deg',
                            '--y': '0px',
                            duration: .2
                        }, {
                            '--success-offset': '0px',
                            '--success-o': 1,
                            duration: .2
                        }]
                    })
                }, 500)
            }
        })

    })
})
