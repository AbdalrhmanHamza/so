# Delete button animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/MWwGbVb](https://codepen.io/aaroniker/pen/MWwGbVb).

From https://dribbble.com/shots/10737893--Delete-Button-Micro-Interaction