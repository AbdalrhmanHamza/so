# Send button animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/milanraring/pen/pogarPQ](https://codepen.io/milanraring/pen/pogarPQ).

Send button animation - Paper Plane