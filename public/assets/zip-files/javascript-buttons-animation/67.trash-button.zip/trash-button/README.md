# Trash button

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/abOXPvN](https://codepen.io/aaroniker/pen/abOXPvN).

