# Button Hover Effects #2

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/abzbRvo](https://codepen.io/aaroniker/pen/abzbRvo).

First version https://codepen.io/aaroniker/pen/bGGVMbY