# Animated  Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/zanewesley/pen/yLgPEON](https://codepen.io/zanewesley/pen/yLgPEON).

A button with a fun confetti click animation written with css and  JavaScript