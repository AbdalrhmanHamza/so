# Like Button (🍏 Event Hashflag)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/ZEWMjoy](https://codepen.io/jh3y/pen/ZEWMjoy).

Was challenged to recreate the Apple Event Hashflag button on Twitter.

Had a go at recreating it with SVG and GreenSock and put my own spin on it with audio and sprinkles!

Enjoy!