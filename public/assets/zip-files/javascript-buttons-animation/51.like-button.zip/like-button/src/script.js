gsap.registerPlugin(MorphSVGPlugin);

const like = document.querySelector('.like');
const background = document.querySelector('.background');
const hearthPath = document.querySelector('.hearth path').getAttribute('d');
const drop = document.querySelector('.drop path');
const dropPath = drop.getAttribute('d');

const size = gsap.getProperty(like, '--size');
const colorDrop = gsap.getProperty(like, '--color-drop');
const colorCircle = gsap.getProperty(like, '--color-circle');
const lineLength = gsap.getProperty(like, '--line-length');
const lineOffset = gsap.getProperty(like, '--line-offset');
const opacityCircle = gsap.getProperty(like, '--opacity-circle');

const playspeed = 1;

const keyframes = [
/*  0 */ 0.00,//s
/*  1 */ 0.20,//s
/*  2 */ 0.25,//s
/*  3 */ 0.35,//s
/*  4 */ 0.40,//s
/*  5 */ 0.50,//s
/*  6 */ 0.55,//s
/*  7 */ 0.65,//s
/*  8 */ 0.70,//s
/*  9 */ 0.75,//s
/* 10 */ 0.90,//s
/* 11 */ 1.10,//s
/* 12 */ 1.25,//s
/* 13 */ 1.42,//s
/* 14 */ 1.60,//s
];

const timespan = (start, end) => ({
  delay: keyframes[start] * (1 / playspeed),
  duration: (keyframes[end] - keyframes[start]) * (1 / playspeed),
});

const handleClick = () => {
  const plusOne = document.createElement('div');
  plusOne.classList.add('plus-one');
  like.appendChild(plusOne);
  
  gsap.killTweensOf(like);
  gsap.killTweensOf(drop);

  /* Drop */
  // Fall
  gsap.fromTo(like, {
    '--ratio-offset-drop': 1,
    '--opacity-drop': 0,
  }, {
    '--opacity-drop': 1,
    '--ratio-offset-drop': 0,
    ...timespan(0, 2),
  });
  // Morph
  gsap.fromTo(drop, {
    morphSVG: dropPath,
  }, {
    morphSVG: { shape: hearthPath, shapeIndex: 3 },
    ...timespan(2, 3),
  })
  // Fade
  gsap.to(like, {
    '--opacity-drop': 0,
    ...timespan(3, 5),
  });
  // Reset
  gsap.to(drop, {
    morphSVG: dropPath,
    ...timespan(5, 5),
  });
  /* Hearth */
  // Rotate
  gsap.fromTo(like, {
    '--ratio-rotate': 1,
  }, {
    '--ratio-rotate': 0.25,
    ...timespan(0, 2),
  });
  gsap.to(like, {
    '--ratio-rotate': 1,
    ...timespan(2, 5),
  });
  // Scale
  gsap.fromTo(like, {
    '--ratio-hearth-scale': 1,
  }, {
    '--ratio-hearth-scale': 0.9,
    ...timespan(1, 2),
  });
  gsap.to(like, {
    '--ratio-hearth-scale': 1.4,
    ...timespan(2, 6),
  });
  gsap.to(like, {
    '--ratio-hearth-scale': 0.95,
    ...timespan(6, 9),
  });
  gsap.to(like, {
    '--ratio-hearth-scale': 1.05,
    ...timespan(9, 10),
  });
  gsap.to(like, {
    '--ratio-hearth-scale': 1,
    ...timespan(10, 11),
  });

  /* Like */
  // Scale
  gsap.fromTo(like, {
    '--ratio-scale': 1,    
  }, {
    '--ratio-scale': 0.5,
    ...timespan(1, 3),
  });
  gsap.to(like, {
    '--ratio-scale': 1.2,
    ...timespan(3, 5),
  });
  gsap.to(like, {
    '--ratio-scale': 0.95,
    ...timespan(5, 8),
  });
  gsap.to(like, {
    '--ratio-scale': 1,
    ...timespan(8, 10),
  });
  
  /* Circle */
  // tint
  gsap.fromTo(like, {
    '--color-circle': colorCircle,
    '--opacity-circle': opacityCircle,    
  }, {
    '--color-circle': colorDrop,
    '--opacity-circle': 1,
    ...timespan(3, 5),
  });
  // reset
  gsap.to(like, {
    '--color-circle': colorCircle,
    '--opacity-circle': opacityCircle,
    ...timespan(11, 14),
  });
  
  /* Lines */
  // Fade in
  gsap.fromTo(like, {
    '--opacity-lines': 0,    
    '--line-length': lineLength,
    '--line-offset': lineOffset,
  }, {
    '--opacity-lines': 1,
    ...timespan(3, 4),
  });
  // Out
  gsap.to(like, {
    '--line-offset': 15,
    ...timespan(4, 6),
  });
  // Collapse
  gsap.to(like, {
    '--line-length': 0,
    '--line-offset': 1,
    ...timespan(6, 8),
  });
  // Fade out
  gsap.to(like, {
    '--opacity-lines': 0,
    ...timespan(7, 8),
  });
  // Reset
  gsap.to(like, {
    '--line-length': lineLength,
    '--line-offset': lineOffset,
    ...timespan(8, 8),
  });
  
  /* Plus-One */
  // scale
  gsap.to(plusOne, {
    '--ratio-scale': 0.5,
    ease: 'elastic',
    ...timespan(4, 14),
  });
  gsap.to(plusOne, {
    '--ratio-offset-y': 1,
    ease: 'none',
    ...timespan(4, 14),
  });
  gsap.to(plusOne, {
    '--ratio-offset-x': .5,
    ease: 'sine.inOut',
    ...timespan(5, 8),
  });
  gsap.to(plusOne, {
    '--ratio-offset-x': -.25,
    ease: 'sine.inOut',
    ...timespan(8, 11),
  });
  gsap.to(plusOne, {
    '--ratio-offset-x': .15,
    ease: 'sine.inOut',
    ...timespan(11, 13),
  });
  gsap.to(plusOne, {
    '--ratio-offset-x': 0,
    ease: 'sine.inOut',
    ...timespan(13, 14),
  });
  gsap.to(plusOne, {
    opacity: 0,
    ease: 'none',
    ...timespan(12, 14),
    onComplete: () => {
      plusOne.remove();
    }
  });

  /* Background */
  // Scale
  gsap.fromTo(background, {
    scale: 1,
  }, {
    scale: 1.1,
    ease: 'sine.inOut',
    ...timespan(3, 5),
  });
  gsap.to(background, {
    scale: 1,
    ease: 'elastic',
    ...timespan(5, 14),
  });
};

like.addEventListener('click', handleClick);
handleClick();
