# Like Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/Zaku/pen/yLemOqx](https://codepen.io/Zaku/pen/yLemOqx).

Inspired by Alex Bender
https://dribbble.com/shots/11654096-Download-Like-Animation