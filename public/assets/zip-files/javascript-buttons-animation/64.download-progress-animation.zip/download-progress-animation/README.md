# Download progress animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/ZEYmPqM](https://codepen.io/aaroniker/pen/ZEYmPqM).

From https://dribbble.com/shots/2012292-Download-transition