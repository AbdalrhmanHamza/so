# #BlackJoy Like Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/Zaku/pen/XWdWMLR](https://codepen.io/Zaku/pen/XWdWMLR).

Twitter #BlackJoy like animation made with gsap

Visit https://hashflaggallery.com to see all animated hashflags from twitter