const svg = document.querySelector('.like');
const inner = document.querySelector('.inner');
const outer = document.querySelector('.outer');
const sparkles = [...document.querySelector('.sparkles').children];
const filled = document.querySelector('.filled');
const stroke = document.querySelector('.stroke');


const playspeed = 1;

const keyframes = [
/*  0 */ 0.00,//s
/*  1 */ 0.10,//s
/*  2 */ 0.20,//s
/*  3 */ 0.25,//s
/*  4 */ 0.30,//s
/*  5 */ 0.35,//s
/*  6 */ 0.40,//s
/*  7 */ 0.60,//s
/*  8 */ 0.65,//s
/*  9 */ 0.70,//s
/*  10 */ 0.75,//s
/*  11 */ 0.76,//s
/*  12 */ 1.00,//s
];

const timespan = (start, end) => ({
  delay: keyframes[start] * (1 / playspeed),
  duration: (keyframes[end] - keyframes[start]) * (1 / playspeed),
});

let liked = false;

const toggle = () => {
  if (liked) {
    gsap.fromTo(stroke,
      { opacity: 0 },
      { opacity: 1, ...timespan(0, 2) },
    );    
    gsap.to(filled,
      { opacity: 0, ...timespan(0, 2) },
    );    
  } else {
    gsap.set([stroke, filled],
      { opacity: 0 },
    );
    gsap.fromTo(outer,
      { opacity: 1, scale: 0.3, svgOrigin: '50 50' },
      { opacity: 1, scale: 1, ...timespan(0, 1) },
    );
    outer.querySelectorAll('*').forEach((path) => {
      gsap.fromTo(path,
        { fill: '#000' },
        { fill: path.getAttribute('fill'), ...timespan(0, 4) },
      );    
    });
    inner.querySelectorAll('*').forEach((path) => {
      gsap.fromTo(path,
        { fill: '#000' },
        { fill: path.getAttribute('fill'), ...timespan(0, 1) },
      );    
    });
    gsap.fromTo(inner,
      { scale: 0.3, opacity: 1, svgOrigin: '50 50' },
      { scale: 1, ...timespan(0, 5) },
    );
    gsap.to([inner, outer],
      { scale: 0, opacity: 0, ...timespan(6, 9) },
    );
    gsap.fromTo(filled,
      { scale: 0, svgOrigin: '50 50', opacity: 1, },
      { scale: 1, ease: 'back.out(2)', ...timespan(6, 12) },
    );
    gsap.fromTo(sparkles.slice(0,4),
      { strokeDashoffset: -5 },
      { strokeDashoffset: -15, ...timespan(6, 10) },
    );
    gsap.fromTo(sparkles.slice(4,8),
      { strokeDashoffset: -5 },
      { strokeDashoffset: -15, ...timespan(5, 9) },
    );
    gsap.fromTo(sparkles.slice(8,12),
      { strokeDashoffset: -5 },
      { strokeDashoffset: -15, ...timespan(4, 8) },
    );
    gsap.fromTo(sparkles.slice(12,16),
      { strokeDashoffset: -5 },
      { strokeDashoffset: -15, ...timespan(3, 7) },
    );
    gsap.fromTo(sparkles.slice(16,20),
      { strokeDashoffset: -5 },
      { strokeDashoffset: -15, ...timespan(2, 6) },
    );
  }
  svg.style.pointerEvents = 'none';
  setTimeout(() => { svg.style.pointerEvents = ''; }, liked ? 200 : 700);
  liked = !liked;
};

svg.addEventListener('click', toggle);

toggle();
