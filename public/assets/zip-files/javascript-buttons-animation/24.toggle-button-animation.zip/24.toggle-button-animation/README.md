# Toggle Button Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/rZPeYQ](https://codepen.io/aaroniker/pen/rZPeYQ).

From https://dribbble.com/shots/1639361-Add-Remove