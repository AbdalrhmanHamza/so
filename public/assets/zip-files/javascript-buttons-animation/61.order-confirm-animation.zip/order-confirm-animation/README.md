# Order confirm animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/eYOVrNa](https://codepen.io/aaroniker/pen/eYOVrNa).

From https://dribbble.com/shots/7105033-Order-Placed-Confirmation