# Play & Pause Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/abzOdRR](https://codepen.io/aaroniker/pen/abzOdRR).

Inspiration https://dribbble.com/shots/4762799-Microinteraction-Exploration-002