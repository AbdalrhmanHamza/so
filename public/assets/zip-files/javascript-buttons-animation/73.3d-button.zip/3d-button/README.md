# 3D button

A Pen created on CodePen.io. Original URL: [https://codepen.io/robin-dela/pen/eYpKKqL](https://codepen.io/robin-dela/pen/eYpKKqL).

Three.js version of Edoardo Mercati's tweet: https://twitter.com/edoardomercati/status/1259879628992282626