# T-Shirt Cannon Button 🚀

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/eYpmBxQ](https://codepen.io/jh3y/pen/eYpmBxQ).

T-Shirt cannon button with GreenSock. 

Not sure why, but the tip of the cannon gets cut off in Chrome sometimes which isn't ideal.

Enjoy! 