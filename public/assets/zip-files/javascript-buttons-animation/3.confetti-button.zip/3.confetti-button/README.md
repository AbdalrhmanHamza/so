# Confetti Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/coopergoeke/pen/wvaYMbJ](https://codepen.io/coopergoeke/pen/wvaYMbJ).

Confetti using JS, SCSS, and a HTML5 canvas.