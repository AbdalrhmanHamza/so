# Heart Fold Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/XWbaJrZ](https://codepen.io/aaroniker/pen/XWbaJrZ).

From https://dribbble.com/shots/3397376-Flip-to-Like