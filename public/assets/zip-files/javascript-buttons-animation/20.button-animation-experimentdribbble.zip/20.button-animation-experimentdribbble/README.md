# Button Animation Experiment - Dribbble

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitsune/pen/beBJBb](https://codepen.io/kitsune/pen/beBJBb).

Another quick pen of button animation based on a Dribbble post I liked by Daniel Jecha - https://dribbble.com/shots/2741994-Button-Experiment