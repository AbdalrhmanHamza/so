// Pen based on Dribbble shot by Daniel Jecha
// https://dribbble.com/shots/2741994-Button-Experiment