# Micro Interactions: Bouncy hover Effect with GSAP

A Pen created on CodePen.io. Original URL: [https://codepen.io/kvncnls/pen/XWBgmYE](https://codepen.io/kvncnls/pen/XWBgmYE).

