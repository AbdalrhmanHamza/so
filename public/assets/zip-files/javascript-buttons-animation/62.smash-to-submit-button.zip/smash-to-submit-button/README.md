# Smash to submit button

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/NWqyego](https://codepen.io/aaroniker/pen/NWqyego).

