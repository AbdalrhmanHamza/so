# Continue Application Hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/dyoMqma](https://codepen.io/aaroniker/pen/dyoMqma).

From https://dribbble.com/shots/9977063-Continue-Application-Hover