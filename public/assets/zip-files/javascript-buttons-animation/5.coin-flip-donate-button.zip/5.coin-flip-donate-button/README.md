# Coin Flip Donate Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/coopergoeke/pen/abZqEbK](https://codepen.io/coopergoeke/pen/abZqEbK).

A simple idea that ended up being really hard to pull off. No 3D elements or transformations are used in this experiment, only 2D elements and some clever math to give the illusion of a 3D coin with real thickness. I'm happy with the results given the limitations of HTML and CSS. 

The coin flipping is actually randomized too -- if you press the button a few times you'll see.