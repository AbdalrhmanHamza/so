# Menu Button Interaction

A Pen created on CodePen.io. Original URL: [https://codepen.io/aybukeceylan/pen/zYNpWdj](https://codepen.io/aybukeceylan/pen/zYNpWdj).

Inspired by: https://dribbble.com/shots/11920943--More-Button-Interaction