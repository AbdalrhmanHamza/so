# Upload File

A Pen created on CodePen.io. Original URL: [https://codepen.io/alphardex/pen/ExjKZxP](https://codepen.io/alphardex/pen/ExjKZxP).

Inspired from this shot: https://dribbble.com/shots/10066653-Upload-File