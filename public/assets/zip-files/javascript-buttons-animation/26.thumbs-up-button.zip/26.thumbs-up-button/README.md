# Thumbs up button

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/ZEbLZrK](https://codepen.io/aaroniker/pen/ZEbLZrK).

