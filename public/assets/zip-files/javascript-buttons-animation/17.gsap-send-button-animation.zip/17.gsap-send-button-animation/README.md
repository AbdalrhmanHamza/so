# GSAP Send Button Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/shahidshaikhs/pen/PoZqNaQ](https://codepen.io/shahidshaikhs/pen/PoZqNaQ).

Button Animation using GSAP animation library