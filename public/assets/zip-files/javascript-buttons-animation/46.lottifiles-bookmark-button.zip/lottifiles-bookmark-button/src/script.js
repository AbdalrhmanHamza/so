let isBookMarked = false;
const button = document.querySelector("#bookmark");

button.addEventListener("click", () => {
	isBookMarked = !isBookMarked;

	if (isBookMarked) {
		button.classList.add("active");
		animation.play();
	} else {
		button.classList.remove("active");
		animation.stop();
	}
});

const animation = lottie.loadAnimation({
	container: document.querySelector("#bookmark-icon"),
	renderer: "svg",
	loop: false,
	autoplay: false,
	speed: 0.8,
	path: "https://assets.codepen.io/907368/bookmark.json"
});
