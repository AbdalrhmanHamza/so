# 3D Explore Menu (Burger)

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/ZEpbVYK](https://codepen.io/aaroniker/pen/ZEpbVYK).

From https://dribbble.com/shots/14235925-Hamburger-Menu-Hover-Effect