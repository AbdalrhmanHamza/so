# (v2) Button - Hold to confirm (Accessible)

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/BayaBpV](https://codepen.io/aaroniker/pen/BayaBpV).

