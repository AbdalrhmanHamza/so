# Button with glow & particles ✨

A Pen created on CodePen.io. Original URL: [https://codepen.io/LukyVj/pen/abRbqgy](https://codepen.io/LukyVj/pen/abRbqgy).

Inspired by https://twitter.com/adrienrochet/status/1642127496823930882

The particle animations are made with SVG

Twitter thread: https://twitter.com/LukyVJ/status/1644780864394412035