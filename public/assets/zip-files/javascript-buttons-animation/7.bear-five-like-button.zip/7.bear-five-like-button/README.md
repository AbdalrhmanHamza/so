# Bear Five Like Button 🐻

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/yLVaJML](https://codepen.io/jh3y/pen/yLVaJML).

An attempted recreate of the brilliant [Dribbble shot from David Huynh](https://dribbble.com/shots/5307333-Paw-Like-Button).

A slight bear twist.

The challenge here was seeing how well this could be recreated with the aid of GSAP.

