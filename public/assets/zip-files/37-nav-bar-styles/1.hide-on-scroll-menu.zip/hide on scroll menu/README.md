# Mobile first - hide on scroll menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/andiio/pen/ARxgGb](https://codepen.io/andiio/pen/ARxgGb).
