$('#nav-toggle').click(function () {
  $('body').toggleClass('open')
})
