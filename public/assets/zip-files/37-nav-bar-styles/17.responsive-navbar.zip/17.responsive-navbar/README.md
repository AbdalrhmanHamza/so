# Responsive Navbar #2

A Pen created on CodePen.io. Original URL: [https://codepen.io/john-chimaobi/pen/rEEpdE](https://codepen.io/john-chimaobi/pen/rEEpdE).
