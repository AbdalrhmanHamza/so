# Bootstrap responsive navbar

A Pen created on CodePen.io. Original URL: [https://codepen.io/muluneh/pen/ZObzGO](https://codepen.io/muluneh/pen/ZObzGO).
