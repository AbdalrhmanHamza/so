# Minimal Nav Bar Concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/DogburnDesign/pen/MWBJab](https://codepen.io/DogburnDesign/pen/MWBJab).
