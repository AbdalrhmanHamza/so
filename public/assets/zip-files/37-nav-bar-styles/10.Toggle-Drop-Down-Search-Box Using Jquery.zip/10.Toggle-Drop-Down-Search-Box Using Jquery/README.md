# Toggle Drop Down Search Box Using Jquery

A Pen created on CodePen.io. Original URL: [https://codepen.io/RajRajeshDn/pen/PJdMrE](https://codepen.io/RajRajeshDn/pen/PJdMrE).
