# Peekaboo Nav Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/jennyveens/pen/GgEdpy](https://codepen.io/jennyveens/pen/GgEdpy).
