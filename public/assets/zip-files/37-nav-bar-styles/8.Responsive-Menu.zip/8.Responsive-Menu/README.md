# #3 Inspiration for Responsive Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/devolk/pen/QpQawQ](https://codepen.io/devolk/pen/QpQawQ).
