# Minimal Image Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/yasgo/pen/vLPyGy](https://codepen.io/yasgo/pen/vLPyGy).
