# Card slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/sbmistry/pen/NWqzyxe](https://codepen.io/sbmistry/pen/NWqzyxe).
