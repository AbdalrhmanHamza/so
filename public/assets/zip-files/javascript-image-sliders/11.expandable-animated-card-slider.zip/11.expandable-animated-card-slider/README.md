# Expandable Animated Card Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/wvzrPoj](https://codepen.io/yudizsolutions/pen/wvzrPoj).
