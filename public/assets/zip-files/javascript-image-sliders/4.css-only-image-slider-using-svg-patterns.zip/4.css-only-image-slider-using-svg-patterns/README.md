# CSS-only image slider using SVG patterns

A Pen created on CodePen.io. Original URL: [https://codepen.io/damianmuti/pen/OgBWej](https://codepen.io/damianmuti/pen/OgBWej).
