// Force redirect to first slide
window.location.href = '#slide-1'

// All images are from https://unsplash.com/
