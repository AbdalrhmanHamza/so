# Responsive Image Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/dfitzy/pen/xZqGVo](https://codepen.io/dfitzy/pen/xZqGVo).
