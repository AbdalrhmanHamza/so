# Information Card Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/andytran/pen/xweoPN](https://codepen.io/andytran/pen/xweoPN).
