# Blog Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/MetA4hor/pen/EoYPNy](https://codepen.io/MetA4hor/pen/EoYPNy).
