# Blog Card Design

A Pen created on CodePen.io. Original URL: [https://codepen.io/rabakilgur/pen/RYpVQz](https://codepen.io/rabakilgur/pen/RYpVQz).
