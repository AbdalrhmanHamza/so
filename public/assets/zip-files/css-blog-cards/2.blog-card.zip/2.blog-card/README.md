# blog card

A Pen created on CodePen.io. Original URL: [https://codepen.io/vbattalshn/pen/zYEJaoz](https://codepen.io/vbattalshn/pen/zYEJaoz).
