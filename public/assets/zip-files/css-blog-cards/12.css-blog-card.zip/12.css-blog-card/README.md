# Pure CSS Blog Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/themodrnhakr/pen/yLzGxyz](https://codepen.io/themodrnhakr/pen/yLzGxyz).
