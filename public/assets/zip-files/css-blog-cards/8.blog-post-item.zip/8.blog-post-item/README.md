# Blog Post Item

A Pen created on CodePen.io. Original URL: [https://codepen.io/nodws/pen/edvjdJ](https://codepen.io/nodws/pen/edvjdJ).
