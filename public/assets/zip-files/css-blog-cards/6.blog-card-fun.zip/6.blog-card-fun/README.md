# Blog Card fun #1

A Pen created on CodePen.io. Original URL: [https://codepen.io/IMarty/pen/zrdYGe](https://codepen.io/IMarty/pen/zrdYGe).
