# Blog Posts Card Layout - Code The Web

A Pen created on CodePen.io. Original URL: [https://codepen.io/Booligoosh/pen/mKPpQp](https://codepen.io/Booligoosh/pen/mKPpQp).
