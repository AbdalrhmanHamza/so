# Layout practice, using grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/bartveneman/pen/PQMzxp](https://codepen.io/bartveneman/pen/PQMzxp).
