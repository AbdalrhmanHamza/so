# #14 - Large Blog Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/daiquiri/pen/bqaVLo](https://codepen.io/daiquiri/pen/bqaVLo).
