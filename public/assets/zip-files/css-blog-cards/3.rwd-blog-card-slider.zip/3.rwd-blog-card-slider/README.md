# rwd blog card slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/vinniv13/pen/OJyEmQN](https://codepen.io/vinniv13/pen/OJyEmQN).
