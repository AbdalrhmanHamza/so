# FlexBox Exercise #4 - Same height cards

A Pen created on CodePen.io. Original URL: [https://codepen.io/veronicadev/pen/WJyOwG](https://codepen.io/veronicadev/pen/WJyOwG).
