# Pure CSS Card w/ Social Icons

A Pen created on CodePen.io. Original URL: [https://codepen.io/markelrayes/pen/ZEGVBZm](https://codepen.io/markelrayes/pen/ZEGVBZm).
