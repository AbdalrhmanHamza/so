# Blog Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/lyon-etyo/pen/OJmyMGd](https://codepen.io/lyon-etyo/pen/OJmyMGd).
