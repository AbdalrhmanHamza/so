# DailyUI #001 | Sign Up Form

A Pen created on CodePen.io Original URL: [https://codepen.io/juliepark/pen/WzpRLw](https://codepen.io/juliepark/pen/WzpRLw).
