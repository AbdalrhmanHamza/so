// No JavaScript, except...
alert(
  "If you are not upset with the design, then it isn't a bad idea to color the grey heart pink.😁"
)
