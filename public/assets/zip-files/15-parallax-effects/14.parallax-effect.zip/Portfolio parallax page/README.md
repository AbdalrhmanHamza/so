# Parallax Example: Firewatch Launch Site

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/GPVXVx](https://codepen.io/ig_design/pen/GPVXVx).
