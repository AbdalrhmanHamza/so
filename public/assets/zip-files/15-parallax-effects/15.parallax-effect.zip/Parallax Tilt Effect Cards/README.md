# Parallax Example: Firewatch Launch Site

A Pen created on CodePen.io. Original URL: [https://codepen.io/AbubakerSaeed/pen/rNNdvqz](https://codepen.io/AbubakerSaeed/pen/rNNdvqz).
