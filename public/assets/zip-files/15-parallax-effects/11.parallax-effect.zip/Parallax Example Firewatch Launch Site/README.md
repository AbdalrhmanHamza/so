# Parallax Example: Firewatch Launch Site

A Pen created on CodePen.io. Original URL: [https://codepen.io/StephenKoller/details/LWBLNW](https://codepen.io/StephenKoller/details/LWBLNW).
