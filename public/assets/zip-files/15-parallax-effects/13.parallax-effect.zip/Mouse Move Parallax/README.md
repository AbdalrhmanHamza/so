# Parallax Example: Firewatch Launch Site

A Pen created on CodePen.io. Original URL: [https://codepen.io/oscicen/pen/zyJeJw](https://codepen.io/oscicen/pen/zyJeJw).
