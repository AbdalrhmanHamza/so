# CSS 404 page

A Pen created on CodePen.io. Original URL: [https://codepen.io/agathaco/pen/WKXREy](https://codepen.io/agathaco/pen/WKXREy).

Main inspiration for this pen: https://codepen.io/YusukeNakaya/pen/BwBgvq