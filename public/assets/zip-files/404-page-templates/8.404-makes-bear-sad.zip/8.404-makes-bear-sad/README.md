# 404 Makes bear sad 🐻😭

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/BaNOJWK](https://codepen.io/jh3y/pen/BaNOJWK).

404 page put together for my new personal site using CSS variables for animation and positioning based on mouse movement. Uses sibling combinator to wipe away those tears when hovering over the link to get out of there! 

Enjoy! 