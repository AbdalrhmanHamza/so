# Illustration for 404 Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/kenchen/pen/MWxZVY](https://codepen.io/kenchen/pen/MWxZVY).

Original <a href="//dribbble.com/shots/1611810-No-Bananas-here?list=users&offset=8">illustration</a> by my colleague John Torres.