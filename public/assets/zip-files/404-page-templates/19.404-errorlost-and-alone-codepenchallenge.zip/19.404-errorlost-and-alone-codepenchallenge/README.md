# 404 Error - Lost and Alone #CodePenChallenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/janmez/pen/LJOdar](https://codepen.io/janmez/pen/LJOdar).

My take for this week's challenge featuring some simple SVG animation 