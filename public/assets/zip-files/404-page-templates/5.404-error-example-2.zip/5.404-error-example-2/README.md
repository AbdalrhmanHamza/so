# 404 Error Example #2

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardpriet/pen/qVZxNo](https://codepen.io/ricardpriet/pen/qVZxNo).

From graphic design to web design. This 404 error example was designed by Yoga Perdana and we have converted into web with pure CSS and minimal HTML using CSS3 gradients and shadows. See more creative examples in the related pens.

Hope you like it :)

Read the full article <a href="https://www.silocreativo.com/en/creative-examples-404-error-css/">here</a>