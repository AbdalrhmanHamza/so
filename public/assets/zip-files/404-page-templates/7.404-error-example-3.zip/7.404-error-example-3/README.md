# 404 Error Example #3  

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardpriet/pen/zPqyvY](https://codepen.io/ricardpriet/pen/zPqyvY).

A 404 error page with plain colors that change depending on the Zero number. All with CSS animations and shadows :)

See more creative examples in the related pens.

Read the full article <a href="https://www.silocreativo.com/en/creative-examples-404-error-css/">here</a>