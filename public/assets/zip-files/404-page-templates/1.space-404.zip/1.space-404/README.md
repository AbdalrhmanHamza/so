# Space 404

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jarowe/pen/KNYxKe](https://codepen.io/Jarowe/pen/KNYxKe).

Animated SVG for the 404 page on Vecteezy.com