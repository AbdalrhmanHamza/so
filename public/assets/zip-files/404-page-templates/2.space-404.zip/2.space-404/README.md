# Space 404

A Pen created on CodePen.io. Original URL: [https://codepen.io/eroxburgh/pen/zYYyEPg](https://codepen.io/eroxburgh/pen/zYYyEPg).

A 404 page made from pure css and a touch of canvas