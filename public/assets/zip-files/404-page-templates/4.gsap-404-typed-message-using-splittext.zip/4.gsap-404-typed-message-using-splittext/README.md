# GSAP 404 typed message using SplitText 

A Pen created on CodePen.io. Original URL: [https://codepen.io/selcukcura/pen/XeQpEv](https://codepen.io/selcukcura/pen/XeQpEv).

