# 404 page

A Pen created on CodePen.io. Original URL: [https://codepen.io/Bidji/pen/rMgQON](https://codepen.io/Bidji/pen/rMgQON).

