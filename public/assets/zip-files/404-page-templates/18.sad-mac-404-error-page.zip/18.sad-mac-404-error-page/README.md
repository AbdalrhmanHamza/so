# Sad Mac 404 Error Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/aPLWJm](https://codepen.io/jkantner/pen/aPLWJm).

A 404 error page based on Sad Mac, which was classic Mac OS’s blue screen of death. The screen was shown if startup failed due to hardware or software issues.

Update 2/16/23: Redone centering to allow scrolling in smaller viewport heights