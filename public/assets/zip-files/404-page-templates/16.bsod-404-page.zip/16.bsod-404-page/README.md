# BSOD 404 Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/igloude/pen/qNNWKr](https://codepen.io/igloude/pen/qNNWKr).

