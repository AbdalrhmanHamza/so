# Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/z-/pen/bwPBjY](https://codepen.io/z-/pen/bwPBjY).

For V. Berezovsky