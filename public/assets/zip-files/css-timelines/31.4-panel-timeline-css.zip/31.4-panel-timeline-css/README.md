# 4 Panel Timeline CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/jeffglenn/pen/KNYoKa](https://codepen.io/jeffglenn/pen/KNYoKa).

CSS only timeline for a client. Mobile styles coming soon.