# Isometric timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/Tims101/pen/yVXOjL](https://codepen.io/Tims101/pen/yVXOjL).

This is isometric timeline created only by CSS and HTML, inspired by picture I found on pinterest: https://s-media-cache-ak0.pinimg.com/564x/4f/15/d7/4f15d75b45138c9123651027459d15ce.jpg