# CSS Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/jtholloran/pen/DzYjgg](https://codepen.io/jtholloran/pen/DzYjgg).

Created this timeline for the company history section of www.meridianapps.com. Uses the LESS CSS framework and some jquery hover/click events.