# Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/TajShireen/pen/JjGvVzg](https://codepen.io/TajShireen/pen/JjGvVzg).

A simple way to customize an unordered list using pseudo-elements.   The list decoration can be anything - even an image.