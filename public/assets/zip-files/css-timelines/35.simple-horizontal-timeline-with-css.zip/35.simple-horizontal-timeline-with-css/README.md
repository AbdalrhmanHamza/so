# Simple Horizontal Timeline with CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/simtoalev/pen/XMvKxK](https://codepen.io/simtoalev/pen/XMvKxK).

A simple horizontal timeline example with CSS.
- Not responsive