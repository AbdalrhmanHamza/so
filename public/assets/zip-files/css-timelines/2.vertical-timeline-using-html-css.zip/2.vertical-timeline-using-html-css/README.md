# Vertical Timeline Using HTML & CSS 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Web_Cifar/pen/jObBvqN](https://codepen.io/Web_Cifar/pen/jObBvqN).

