# Building a Horizontal Timeline With CSS and JavaScript

A Pen created on CodePen.io. Original URL: [https://codepen.io/tutsplus/pen/ZKpNwm](https://codepen.io/tutsplus/pen/ZKpNwm).

Read full tutorial by George Martsoukos [on Envato Tuts+](https://webdesign.tutsplus.com/tutorials/building-a-horizontal-timeline-with-css-and-javascript--cms-28378)!