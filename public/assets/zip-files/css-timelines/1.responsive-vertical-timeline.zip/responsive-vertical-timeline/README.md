# responsive vertical timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/auntyginger/pen/adpvoB](https://codepen.io/auntyginger/pen/adpvoB).

This is build with SCSS and an attempt to follow a BEM structure. and hopefully mobile-friendly.