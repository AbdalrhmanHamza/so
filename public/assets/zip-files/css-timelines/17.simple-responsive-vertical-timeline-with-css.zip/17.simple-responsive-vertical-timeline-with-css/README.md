# Simple responsive vertical timeline with css

A Pen created on CodePen.io. Original URL: [https://codepen.io/hassan-kamal/pen/NNvYEQ](https://codepen.io/hassan-kamal/pen/NNvYEQ).

