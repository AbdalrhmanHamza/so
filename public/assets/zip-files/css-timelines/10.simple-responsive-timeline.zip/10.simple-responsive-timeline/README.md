# Simple responsive timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/thischarmingsam/pen/wGGGby](https://codepen.io/thischarmingsam/pen/wGGGby).

