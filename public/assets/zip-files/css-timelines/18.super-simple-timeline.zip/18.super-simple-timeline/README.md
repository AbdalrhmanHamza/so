# Super Simple Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/htmlcodex/pen/LYGjPgV](https://codepen.io/htmlcodex/pen/LYGjPgV).

Super simple vertical timeline code for creating a vertical timeline. Font Awesome icons included.