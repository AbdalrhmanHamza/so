# horizontal timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/ritz078/pen/LGRWjE](https://codepen.io/ritz078/pen/LGRWjE).

