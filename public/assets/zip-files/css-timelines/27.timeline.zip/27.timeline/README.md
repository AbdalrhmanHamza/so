# Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/clintabrown/pen/DQmPbp](https://codepen.io/clintabrown/pen/DQmPbp).

Based on the Dribbble shot Timeline by Gabe Abadilla - http://dribbble.com/shots/562262-Timeline