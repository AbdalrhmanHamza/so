# Timeline Custom Counter with Gradient Border

A Pen created on CodePen.io. Original URL: [https://codepen.io/letsbleachthis/pen/YJgNpv](https://codepen.io/letsbleachthis/pen/YJgNpv).

