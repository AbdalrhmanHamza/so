# CSS3 Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/P233/pen/nbgRXw](https://codepen.io/P233/pen/nbgRXw).

Please set the $vertical variable to false to see the horizontal version.