# Vertical dark timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/Devcrud/pen/XWboGgL](https://codepen.io/Devcrud/pen/XWboGgL).

