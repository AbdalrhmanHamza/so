# Horizontal timeline mockup v2

A Pen created on CodePen.io. Original URL: [https://codepen.io/TriVector/pen/EPJqqd](https://codepen.io/TriVector/pen/EPJqqd).

