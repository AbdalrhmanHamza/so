# responsive timeline v3

A Pen created on CodePen.io. Original URL: [https://codepen.io/cjl750/pen/mXbMyo](https://codepen.io/cjl750/pen/mXbMyo).

A timeline on desktop that switches to clickable circles on mobile. Content changes as you click the circles. This pen is a re-imagining of https://codepen.io/cjl750/pen/XMyRoB.