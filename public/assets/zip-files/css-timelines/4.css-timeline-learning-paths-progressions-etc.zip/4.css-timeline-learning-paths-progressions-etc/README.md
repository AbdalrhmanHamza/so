# CSS Timeline (learning paths, progressions, etc)

A Pen created on CodePen.io. Original URL: [https://codepen.io/taraswenson/pen/xyMmox](https://codepen.io/taraswenson/pen/xyMmox).

