# CSS Timeline v2

A Pen created on CodePen.io. Original URL: [https://codepen.io/triss90/pen/GqRKeW](https://codepen.io/triss90/pen/GqRKeW).

