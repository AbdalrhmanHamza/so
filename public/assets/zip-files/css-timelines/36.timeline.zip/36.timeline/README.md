# Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/pouretrebelle/pen/DbrKVp](https://codepen.io/pouretrebelle/pen/DbrKVp).

Horizontal timeline with cute hover transition