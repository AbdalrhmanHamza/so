# Advanced TimeLine : HTML / CSS / JavaScript

A Pen created on CodePen.io. Original URL: [https://codepen.io/mo7amedk7alid29/pen/dRoMwo](https://codepen.io/mo7amedk7alid29/pen/dRoMwo).

