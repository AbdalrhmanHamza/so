# File Upload With Bootstrap File Input

A Pen created on CodePen.io. Original URL: [https://codepen.io/piyushpd139/pen/ExmpXLz](https://codepen.io/piyushpd139/pen/ExmpXLz).

Bootstrap File Input is a field which the user can use to upload one or more files (photos, documents or any other file type) from local storage.