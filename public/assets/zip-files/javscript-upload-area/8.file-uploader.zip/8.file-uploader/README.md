# File Uploader

A Pen created on CodePen.io. Original URL: [https://codepen.io/mmhuntsberry/pen/QowZwR](https://codepen.io/mmhuntsberry/pen/QowZwR).

A simple drag and drop file uploader modal with firebase storage.  