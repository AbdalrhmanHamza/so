# File Upload & Image Preview

A Pen created on CodePen.io. Original URL: [https://codepen.io/uixmat/pen/yadZXv](https://codepen.io/uixmat/pen/yadZXv).

A pure Javascript file upload with drop zone (drag & drop) and image preview.

- **No Jquery or Plugins required.**

[Follow me on Twitter](https://twitter.com/mattsince87)
