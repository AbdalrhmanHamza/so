# Drag and Drop File Uploader

A Pen created on CodePen.io. Original URL: [https://codepen.io/SunilSalaria/pen/jOvJewZ](https://codepen.io/SunilSalaria/pen/jOvJewZ).

