# Simple multi file uploader

A Pen created on CodePen.io. Original URL: [https://codepen.io/hanzketup/pen/gEmRpb](https://codepen.io/hanzketup/pen/gEmRpb).

