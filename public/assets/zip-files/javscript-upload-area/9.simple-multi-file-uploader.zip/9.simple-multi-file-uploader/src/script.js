let generate_file_list = files => {
  document.querySelector('.file_list').innerHTML = [...files].map(file => `
          <div class="file_uploaded_item">
            <i class="fas fa-file-invoice file_uploaded_item_icon"></i>
            <div>
              <p>${file.size}kb | ${file.type}</p>
              <h4>${file.name}</h4>
            </div>
            <!--<i class="fas fa-times-circle file_uploaded_item_close"></i>-->
          </div>
  `).join(' ')
}

const inputElement = document.getElementById("dropzone")
inputElement.addEventListener("change", function()  {
  const fileList = this.files;
  generate_file_list(document.getElementById("dropzone").files)
  console.log(document.getElementById("dropzone").files)
}, false)