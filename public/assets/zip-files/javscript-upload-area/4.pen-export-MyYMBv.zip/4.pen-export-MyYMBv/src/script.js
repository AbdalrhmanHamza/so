Dropzone.options.myAwesomeDropzone = {
  dictDefaultMessage: "<i class='fa fa-cloud-upload'></i> Upload your experience", // The name that will be used to transfer the file
  maxFilesize: 2, // MB
  accept: function(file, done) {
    $('.upload-area').hide();
    $('.load').show();
    setTimeout(function(){ $('.load').hide();
                         $('.success').addClass('animated bounceIn');
                         }, 4000)}};