# Responsive Animated File Uploader

A Pen created on CodePen.io. Original URL: [https://codepen.io/burnaDLX/pen/YxxEbj](https://codepen.io/burnaDLX/pen/YxxEbj).

