# Images Uploader (Drag & browse) 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Ali-Majed/pen/BaRoyrG](https://codepen.io/Ali-Majed/pen/BaRoyrG).

This Is A Simple Images Uploader 
You Can Drop Or Browse Your Image

i hope you like it 
thank you so much <3