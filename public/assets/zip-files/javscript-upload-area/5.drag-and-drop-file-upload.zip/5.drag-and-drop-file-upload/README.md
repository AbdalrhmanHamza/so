# Drag And Drop File Upload

A Pen created on CodePen.io. Original URL: [https://codepen.io/code-boxx/pen/bGYVjqz](https://codepen.io/code-boxx/pen/bGYVjqz).

A simple drag-and-drop file uploader made with  pure HTML Javascript.

Full tutorial and explanation on **[Code Boxx](https://code-boxx.com/simple-drag-and-drop-file-upload/)**.