var ddup = {
  // (A) ATTACH DRAG-DROP FILE UPLOADER
  init : instance => {
    // (A1) FLAGS + CSS CLASS
    instance.target.classList.add("upwrap");
    instance.upqueue = []; // upload queue
    instance.uplock = false; // uploading in progress
    instance.size = instance.size==undefined ? 0 : instance.size; // max upload size
    instance.types = instance.types==undefined ? [] : instance.types; // allowed file types
    for (let [k,v] of Object.entries(instance.types)) { instance.types[k] = v.toLowerCase(); }

    // (A2) DRAG-DROP HTML INTERFACE
    instance.target.innerHTML =
      `<div class="updrop">Drop Files Here To Upload.</div>
       <div class="upstat"></div>`;
    instance.hzone = instance.target.querySelector(".updrop");
    instance.hstat = instance.target.querySelector(".upstat");

    // (A3) HIGHLIGHT DROP ZONE ON DRAG ENTER
    instance.hzone.ondragenter = e => {
      e.preventDefault();
      e.stopPropagation();
      instance.hzone.classList.add("highlight");
    };
    instance.hzone.ondragleave = e => {
      e.preventDefault();
      e.stopPropagation();
      instance.hzone.classList.remove("highlight");
    };

    // (A4) DROP TO UPLOAD FILE
    instance.hzone.ondragover = e => {
      e.preventDefault();
      e.stopPropagation();
    };
    instance.hzone.ondrop = e => {
      e.preventDefault();
      e.stopPropagation();
      instance.hzone.classList.remove("highlight");
      ddup.queue(instance, e.dataTransfer.files);
    };
  },

  // (B) UPLOAD QUEUE
  // * AJAX IS ASYNCHRONOUS, UPLOAD QUEUE PREVENTS SERVER FLOOD
  queue : (instance, files) => {
    // (B1) PUSH FILES INTO QUEUE + GENERATE HTML ROW
    for (let f of files) {
      f.hstat = document.createElement("div");
      f.hstat.className = "uprow";
      f.hstat.innerHTML =
        `<div class="upfile">${f.name} (${f.size} bytes)</div>
         <div class="upprog">
           <div class="upbar"></div>
           <div class="uppercent">0%</div>
         </div>`;
      f.hbar = f.hstat.querySelector(".upbar");
      f.hpercent = f.hstat.querySelector(".uppercent");
      instance.hstat.appendChild(f.hstat);

      // (B1-2) FILE SIZE CHECK
      if (instance.size!=0 && f.size>instance.size) {
        f.hpercent.classList.add("bad");
        f.hpercent.innerHTML = `Over upload limit of ${instance.size} bytes`;
      }
      
      // (B1-3) FILE TYPE CHECK
      else if (instance.types.length>0 && !instance.types.includes(f.name.split(".").pop().toLowerCase())) {
        f.hpercent.classList.add("bad");
        f.hpercent.innerHTML = `File type not allowed`;
      }
      
      // (B1-4) CHECKS OK - ADD TO UPLOAD QUEUE
      else { instance.upqueue.push(f); }
    }

    // (B2) UPLOAD!
    ddup.go(instance);
  },

  // (C) AJAX UPLOAD
  go : instance => { if (!instance.uplock && instance.upqueue.length!=0) {
    // (C1) UPLOAD STATUS UPDATE
    instance.uplock = true;

    // (C2) PLUCK OUT FIRST FILE IN QUEUE
    let thisfile = instance.upqueue[0];
    instance.upqueue.shift();

    // (C3) UPLOAD DATA
    let data = new FormData();
    data.append("upfile", thisfile);
    if (instance.data) { for (let [k, v] of Object.entries(instance.data)) {
      data.append(k, v);
    }}

    // (C4) SIMULATED UPLOAD FOR DEMO
    let a = 0, timer = setInterval(() => {
      let r = (25 * a) + "%";
      thisfile.hbar.style.width = r;
      thisfile.hpercent.innerHTML = r;
      if (r=="100%") {
        clearInterval(timer);
        instance.uplock = false;
        ddup.go(instance);
      } else { a++; }
    }, 500);
    
    /* THIS SHOULD ACTUALLY HAPPEN
    // (C4) AJAX UPLOAD
    let xhr = new XMLHttpRequest();
    xhr.open("POST", instance.action);

    // (C5) UPLOAD PROGRESS
    let percent = 0, width = 0;
    xhr.upload.onloadstart = e => {
      thisfile.hbar.style.width = 0;
      thisfile.hpercent.innerHTML = "0%";
    };
    xhr.upload.onloadend = e => {
      thisfile.hbar.style.width = "100%";
      thisfile.hpercent.innerHTML = "100%";
    };
    xhr.upload.onprogress = e => {
      percent = Math.ceil((e.loaded / e.total) * 100) + "%";
      thisfile.hbar.style.width = percent;
      thisfile.hpercent.innerHTML = percent;
    };

    // (C6) UPLOAD COMPLETE
    xhr.onload = function () {
      // (C6-1) ERROR
      if (this.response!= "OK" || this.status!=200) {
        thisfile.hpercent.innerHTML = this.response;
      }

      // (C6-2) NEXT BETTER PLAYER!
      else {
        thisfile.hbar.style.width = "100%";
        thisfile.hpercent.innerHTML = "100%";
        instance.uplock = false;
        ddup.go(instance);
      }
    };

    // (C7) GO!
    xhr.send(data);*/
  }}
};

// (D) ATTACH UPLOADER
window.addEventListener("load", () => {
  ddup.init({
    target : document.getElementById("demo"), // target HTML <div>
    // action : "dd-upload.php", // server-side upload handler
    // data : { key : "value" } // optional, extra post data
    size : 100000, // optional, max upload size 100kb
    types : ["jpg", "jpeg", "webp", "png", "gif"] // optional, allowed file extensions
  });
});